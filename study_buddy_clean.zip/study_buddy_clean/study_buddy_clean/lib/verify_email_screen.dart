import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'dart:async'; // For Timer

class VerifyEmailScreen extends StatefulWidget {
  const VerifyEmailScreen({Key? key}) : super(key: key);

  @override
  State<VerifyEmailScreen> createState() => _VerifyEmailScreenState();
}

class _VerifyEmailScreenState extends State<VerifyEmailScreen> {
  bool isEmailVerified = false;
  Timer? timer;
  bool canResendEmail = false;

  @override
  void initState() {
    super.initState();
    // Check if user is already verified (e.g., if they came back after verifying)
    isEmailVerified = FirebaseAuth.instance.currentUser?.emailVerified ?? false;

    if (!isEmailVerified) {
      sendVerificationEmail(); // Send email if not already verified
      timer = Timer.periodic(
        const Duration(seconds: 3), // Check verification status every 3 seconds
        (_) => checkEmailVerified(),
      );
    }
  }

  @override
  void dispose() {
    timer?.cancel(); // Cancel timer when screen is disposed
    super.dispose();
  }

  Future<void> sendVerificationEmail() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        await user.sendEmailVerification();
        setState(() {
          canResendEmail = false; // Disable resend button immediately after sending
        });
        await Future.delayed(const Duration(seconds: 5)); // Wait before allowing resend
        setState(() {
          canResendEmail = true;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Verification email sent!')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to send verification email: ${e.toString()}')),
      );
    }
  }

  Future<void> checkEmailVerified() async {
    // Reload user to get the latest emailVerified status
    await FirebaseAuth.instance.currentUser?.reload();
    setState(() {
      isEmailVerified = FirebaseAuth.instance.currentUser?.emailVerified ?? false;
    });

    if (isEmailVerified) {
      timer?.cancel(); // Stop the timer if email is verified
      Navigator.pushReplacementNamed(context, '/home'); // Navigate to home
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Verify Your Email')),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (!isEmailVerified)
              const Text(
                'A verification email has been sent to your email address.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 18),
              ),
            if (!isEmailVerified)
              const SizedBox(height: 10),
            if (!isEmailVerified)
              const Text(
                'Please check your inbox (and spam folder) and click on the verification link.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
            if (isEmailVerified)
              Column(
                children: [
                  const Icon(Icons.check_circle_outline, color: Colors.green, size: 80),
                  const SizedBox(height: 20),
                  const Text(
                    'Your email has been successfully verified!',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () => Navigator.pushReplacementNamed(context, '/home'),
                    child: const Text('Go to Home Screen'),
                  ),
                ],
              ),
            if (!isEmailVerified)
              const SizedBox(height: 30),
            if (!isEmailVerified)
              ElevatedButton(
                onPressed: canResendEmail ? sendVerificationEmail : null, // Disable if recently sent
                child: const Text('Resend Verification Email'),
              ),
            if (!isEmailVerified)
              TextButton(
                onPressed: () async {
                  await FirebaseAuth.instance.signOut();
                  Navigator.pushReplacementNamed(context, '/'); // Go back to login
                },
                child: const Text('Cancel and Go Back to Login'),
              ),
          ],
        ),
      ),
    );
  }
}