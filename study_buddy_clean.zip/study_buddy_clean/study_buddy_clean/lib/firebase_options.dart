import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    return const FirebaseOptions(
      apiKey: 'AIzaSyBcfd4pxHLYA5-W-4WpZlspUQSKGq9exPQ',
      appId: '1:482187464365:web:331b772244db3556ac0024',
      messagingSenderId: '482187464365',
      projectId: 'study-buddy-app-609a0',
      authDomain: 'study-buddy-app-609a0.firebaseapp.com',
      storageBucket: 'study-buddy-app-609a0.appspot.com',
    );
  }
}
