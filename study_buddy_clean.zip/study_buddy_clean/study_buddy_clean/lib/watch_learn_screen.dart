import 'package:flutter/material.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

class WatchLearnScreen extends StatelessWidget {
  const WatchLearnScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final List<String> videoIds = ['dQw4w9WgXcQ', '9bZkp7q19f0', 'M7lc1UVf-VE'];

    return Scaffold(
      appBar: AppBar(title: const Text('Watch & Learn')),
      body: ListView.builder(
        itemCount: videoIds.length,
        itemBuilder: (context, index) {
          final controller = YoutubePlayerController(
            initialVideoId: videoIds[index],
            flags: const YoutubePlayerFlags(autoPlay: false),
          );
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: YoutubePlayer(controller: controller),
          );
        },
      ),
    );
  }
}
