import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('StudyBuddy')),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(color: Colors.deepPurple),
              child: Text('StudyBuddy Menu', style: TextStyle(color: Colors.white, fontSize: 24)),
            ),
            ListTile(title: const Text('Start Learning'), onTap: () => Navigator.pop(context)),
            ListTile(title: const Text('Topics by Course'), onTap: () => Navigator.pop(context)),
            ListTile(title: const Text('Watch & Learn'), onTap: () => Navigator.pushNamed(context, '/watch')),
            ListTile(title: const Text('FunTime MCQs'), onTap: () => Navigator.pop(context)),
            ListTile(title: const Text('Daily Meme + Concept'), onTap: () => Navigator.pop(context)),
            ListTile(title: const Text('Logout'), onTap: () => Navigator.pushReplacementNamed(context, '/')),
          ],
        ),
      ),
      body: const Center(child: Text('Welcome to StudyBuddy!')),
    );
  }
}
