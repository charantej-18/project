package com.example.study_buddy

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
